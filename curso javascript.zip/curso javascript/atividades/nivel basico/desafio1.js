console.log("bem-vindo!")
const prompt = require("prompt-sync")();
let nome = prompt("digite o seu nome:");
console.log(`seu nome é: ${nome}`);


//Verificar maioridade:
let idade = Number(prompt("Digite a sua idade: ")); // Convertendo para número
if (idade >= 18) {
    console.log("Você é maior de idade.");
} else {
    console.log("Você é menor de idade.");
}

//Verificar se um número é positivo ou negativo:
let numero = Number(prompt("Digite um número qualquer: "));
if (numero > 0) {
    console.log("O número é positivo.");
} else if (numero < 0) {
    console.log("O número é negativo.");
} else {
    console.log("O número é zero.");
}

//Aprovação em uma prova:
let nota = Number(prompt("Digite a nota do aluno (0 a 100): "));

if (nota >= 60) {
    console.log("Aprovado");
} else {
    console.log("Reprovado");
}

//Verificar se um número é positivo, negativo ou zero:
let numero1 = Number(prompt("Digite um número: "));

if (numero1 > 0) {
    console.log("O número é positivo.");
} else if (numero < 0) {
    console.log("O número é negativo.");
} else {
    console.log("O número é zero.");
}


//Classificação de idade:
let idade1 = Number(prompt("Digite sua idade: "));

if (idade1 >= 0 && idade <= 12) {
    console.log("Você é uma Criança.");
} else if (idade >= 13 && idade <= 17) {
    console.log("Você é um Adolescente.");
} else if (idade >= 18) {
    console.log("Você é um Adulto.");
} else {
    console.log("Idade inválida.");
}

//Verificar se um número é par ou ímpar:
let numero3 = Number(prompt("Digite um número: "));

if (numero3 % 2 === 0) {
    console.log("O número é divisível por 2 (par).");
} else {
    console.log("O número não é divisível por 2 (ímpar).");
}