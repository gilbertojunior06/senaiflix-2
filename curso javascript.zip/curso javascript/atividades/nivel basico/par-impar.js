//Verificar se um número é par ou ímpar:
let numero3 = Number(prompt("Digite um número: "));

if (numero3 % 2 === 0) {
    console.log("O número é divisível por 2 (par).");
} else {
    console.log("O número não é divisível por 2 (ímpar).");
}