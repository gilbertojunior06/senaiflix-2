//Aprovação em uma prova:
let nota = Number(prompt("Digite a nota do aluno (0 a 100): "));

if (nota >= 60) {
    console.log("Aprovado");
} else {
    console.log("Reprovado");
}