//Verificar se um número é positivo, negativo ou zero:
let numero1 = Number(prompt("Digite um número: "));

if (numero1 > 0) {
    console.log("O número é positivo.");
} else if (numero < 0) {
    console.log("O número é negativo.");
} else {
    console.log("O número é zero.");
}