//Classificação de idade:
let idade1 = Number(prompt("Digite sua idade: "));

if (idade1 >= 0 && idade <= 12) {
    console.log("Você é uma Criança.");
} else if (idade >= 13 && idade <= 17) {
    console.log("Você é um Adolescente.");
} else if (idade >= 18) {
    console.log("Você é um Adulto.");
} else {
    console.log("Idade inválida.");
}