console.log("bem-vindo!")
const prompt = require("prompt-sync")();
let nome = prompt("digite o seu nome:");
console.log(`seu nome é: ${nome}`);


//Verificar maioridade:
let idade = Number(prompt("Digite a sua idade: ")); // Convertendo para número
if (idade >= 18) {
    console.log("Você é maior de idade.");
} else {
    console.log("Você é menor de idade.");
}