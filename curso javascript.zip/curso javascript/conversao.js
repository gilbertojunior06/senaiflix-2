// tipo de conversão

// conversão implícita (coerção de tipo)
console.log("5" + 5);
console.log("5" - 2);
console.log("5" * 2);
console.log("5" /2);


// conversão eplícita
let numero = 21;
console.log(typeof numero); // "number"

let convertido = String(numero);
console.log(typeof convertido); // "string"

numero = "21";
convertido = Number(numero);
console.log(typeof convertido); // "number"


let bool = true;
let conversao2 = string (bool);
console.log(typeof conversao2);