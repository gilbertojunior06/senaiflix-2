let nome = "joão"; //variavel que armazena uma string
const idade = 21;// variave que armazena um numero
var cidade = "São paulo" // variavl que amarzena string

// (const) = variael que nõ e possivel mudar o valor dela por meio de codigo

// (var) = variavel que é possivel mudar o valor dela no meio do codigo

// (let) = (var) porem mais atualizado, por conta de que o var ser discontinuado

// mostrar a variavel nime no terminal
console.log(nome)

// mostrar uma  frase com todas as variaveis criadas
console.log("O meu nome é " + nome + ", eu tenho" + idade + "e eu nasci em " + cidade);

console.log(`o meu nome é ${nome}, eu tenho ${idade} anos e nasci em ${cidade}`);

// variaveis Boolan
let estaChovendo = false; //varivel Boolean que indica que esa falso o valor
let taNublado = true; //varivel Boolean que indica que esa verdadeiro o valor

// variaveis Undefined
let marca;
console.log(marca); // underfind

// variaveis null
let endereco = null;

// tipo primativo d variavel
// typeof
console.log(typeof nome);