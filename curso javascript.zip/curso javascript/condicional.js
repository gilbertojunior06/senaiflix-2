// operadores Relacionais

// > (maior que)
// < (menor que)
// >= (maior ou igual)
// <= (menor ou igual)
// == (igualdade, sem verificar o tipo)
// === (igualdade estrita, verifica o tipo)
// != (diferente. sem verificar o tipo)
// !== (diferente estrito ,verificar o tipo)

let numero = "21";
if( numero == 21){
    console.log ("ok")
}

if (numero === 21) {
    console.log(ok2)
}

let bool =true;

if (boll == "true"){
    console.log("sim entrou o if")
}

// ------------------------------------------------------------------------

let variael1 = "2"
let variael2 = "4"
let bool2 = false

if (variael1 == 3){
    console.log(`A variavel1 tem esse valor`);
}else{
    console.log(`a variavel não tem valor!`);
}

// condicional aninhada
if(variael1 == 2){
    console.log ("A variavel tem esse valor");
    if (variael2 ==4){
        console.log("a variavel2 tem esse valor");
    }else{
        console.log("a variavel2 não tem esse valor");
    }
}else{
    console.log("a variavel não tem esse valor")
}


// condicional (diferente)

console.log(1 != '1'); // false (valores sãp iguais)
console.log(1 !== '1') // true  (valores são diferentes)
if()